import CreateQuestionSetForm from "../../components/QuestionSet/CreateQuestionSetForm";

function CreateQuestionSetPage() {
  return (
    <div>
      <CreateQuestionSetForm />
    </div>
  );
}

export default CreateQuestionSetPage;
