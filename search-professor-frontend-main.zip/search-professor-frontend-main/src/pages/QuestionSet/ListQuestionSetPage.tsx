import ListQuestionSet from "../../components/QuestionSet/ListQuestionSet";

function ListQuestionSetPage() {
  return (
    <div>
      <ListQuestionSet />
    </div>
  );
}

export default ListQuestionSetPage;
