import AuthHomePage from "../components/HomePage/AuthHomePage";

function HomePage() {
  return (
    <div>
      <AuthHomePage />
    </div>
  );
}

export default HomePage;
