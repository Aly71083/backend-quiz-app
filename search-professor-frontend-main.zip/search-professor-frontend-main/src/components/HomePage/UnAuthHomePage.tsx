function UnAuthHomePage() {
  return <div>UnAuthHomePage</div>;
}

export default UnAuthHomePage;
