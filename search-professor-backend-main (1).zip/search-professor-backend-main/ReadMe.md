// ENV //

AUTH_SECRET_KEY=your_secret_key_here
MONGO_URI=your_mongo_db_url
